#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>

typedef strcut bonus {
        int num_token;
        int value;
        chat ** seq;
} Bonus;
typedef struct cell {
    char hex[2];
} Cell;

typedef struct move {
    int row;
    int col;
} Move;
void readBonus(Bonus ** bonus_arr, int * bonus_size) {
    FILE * fp;
    int i,j;
    int num_token, num_value;
    char tok_seq[100];
    if ((fp = fopen("bonus.txt", "r")) == NULL) {
        printf("Errore");
        return;
    }
    fscanf(fp, "%d", *bonus_size);
    bonus_arr = (bonus *) malloc(bonus_size * sizeof(bonus_size));
    for( i = 0, i < *bonus_size; i++) {
        fscanf(fp, "%d %d %s", num_token, num_valore, &tok_seq);
        bonus_arr[i].seq = malloc(num_token * sizeof(char) * 2);
// leggo la token sequence e i valori e li salvo all'interno dell'array
    }
}
int main () {
    cell ** matrix;
    Bonus * bonus_arr;
    int matrix_size, bonus_size, len;
    cell * moves;
    readMatrix(&matrix, &matrix_size);
    readBonus(&bonus_arr, &bonus_size);
    printf("Inserire la lunghezza per cui cercare il percorso migliore");
    scanf("%s", len);
    moves = (cell *)malloc(len * sizeof(cell));
    getBestSequence(matrix, matrix_size, bonus_arr, bonus_size, len, &moves);
}
void readMatrix(cell *** matrix, int * matrixSize) {
    FILE * fp;
    int i, j;

    if ((fp = fopen("grid.txt", "r")) == NULL) {
        printf("Erorre nella lettura del file");
        return 0;
    }
    fscanf(fp, "%d", *matrix_size);
    (*matrix) = (cell *) malloc ((*matrix_size) * sizeof(cell));
    for (i = 0; i < *matrix_size; i++) {
        (*matrix)[i] = cell( *) malloc ((*matrix_size) * sizeof(cell));
        for(j= 0; j < *matrix_size; j++) {
            fscanf(fp, "%s", &((*matrix)[i][j])->hex);
        }
    }
}

int ValidMove(move fromM, move toM) {
    if ((fromM.row == toM.row || fromM.col == toM.col) && !(fromM.row == toM.row && fromM.col == to
        M.col))
    return 0;
}
int VerifyValidSequence(move * moves, int movCnt, cell ** Matrix, int matrix_size, int bonus_no) {
//int takenHex[bonus_no];
//int takenCnt = 0;
    int valid = 1;
    move prevMove = moves[0];
    for(int i = 1; i < movCnt && valid == 1; i++) {
        if (ValidMove(prevMove, moves[i])) {
//for(int j = 0; j < takenCnt && valid == 1; j++)
//if (strcmp(takenHex[j], Matrix[moves[i].row][moves[j].col])
            valid = 0;
        }
    }
    return valid;
}

int getBestSequence(cell ** matrix, int matrix_size, bonus * b, int bonus_size, int reqBSize, move ** be
                    stBuffer) {
// funzione wrapper per le chiamate ricorsive
    move * m = (move *)malloc(reqBSize * sizeof(move *);
    int bestValue;
    m[0]->row = 0;
    m[0]->col = 0;
    bestSeq(0, &m, matrix, matrix_size, b, bonus_size, &bestValue, reqBSize, bestBuffer);
    free(m);
    return bestValue;
}
int getCurrSeqValue(move ** m, cell ** matrix, bonus *b, int bonus_size, int reqSize) {
// Qui posso supporre che la sequenza sia valida in quanto ho usato il pruning sulle richieste preced
    enti
// Li userò come vettori colonna per salvarmi indice e se un bonus è stato preso
    int m_array[req_size];
    int supp_index = 0;
    int supp_bonusi = 0;
    int value = 0;
    for(int i = 0; i < req_size; i++) {
        supp_bonusi = 0;
        for(int j = 0; j < bonus_size; j++) {
            if (strcmp(matrix[m[i]->row][m[i]->col], bonus[j].seq[supp_bonusi])
                supp_index = j;
            supp_bonusi++;
            m_array[i] = 1;
            if (supp_bonusi > bonus[j].num_token)
                value = bonus[j].value;
        }
    }
    return value;
}
void bestSeq(int step, move ** m, cell ** matrix, int matrix_size, bonus * b, int bonus_size, int * currBestValue, int reqSize, move ** bestBuffer) {
    int fixedMove, c, r, currValue, i;
    move suppMove;
    if (step > reqBsize) {
        currValue = getCurrSeqValue();
        if(currValue > currBestValue) {
            for(i = 0; i < reqSize; i++) {
                BestBuffer[i]->row = m[i]->row;
                BestBuffer[i]->col = m[i]->col;
            }
        }
    }
    // definisco che mi muoverò sulle righe, quindi fisso la colonna
    c = m[step-1]->col;
    for(r = 0; r < matrix_size; r++) {
        m[step]->col = c;
        m[step]->row = r;
        if (VerifyValidSequence(m, step, matrix, matrix_size, bonus_size))
            bestSeq(step+1, m, matrix, matrix_size, b, bonus_size, currBestValue, reqSize, bestBuffer);
    }
    t = m[step-1]->row;
    for(c = 0; c < matrix_size; c++) {
        m[step]-> col = c;
        m[step]-> row = r;
        if (VerifyValidSequence(m, step, matrix, matrix_size, bonus_size))
            bestSeq(step+1, m, matrix, matrix_size, b, bonus_size, currBestValue, reqSize, bestBuffer);
    }
}