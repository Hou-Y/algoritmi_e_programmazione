file(REMOVE_RECURSE
  "CMakeFiles/Esame_230702.dir/main.c.o"
  "CMakeFiles/Esame_230702.dir/main.c.o.d"
  "Esame_230702"
  "Esame_230702.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Esame_230702.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
