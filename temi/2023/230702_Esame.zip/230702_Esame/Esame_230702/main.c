#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

typedef struct cell {
    char hex[3];
} Cell;

typedef struct bonus {
        int num_token;
        int value;
        Cell * seq;
} Bonus;

typedef struct move {
    int row;
    int col;
} Move;

void readMatrix(Cell *** matrix, int * matrix_size);
void readBonus(Bonus ** bonus_arr, int * bonus_size);
void freeMatrix(Cell ** matrix, int matrix_size);
void freeBonus(Bonus * bonus_arr, int bonus_size);
int ValidMove(Move fromM, Move toM);
int VerifyValidSequence(Move * moves, int movCnt);
int getBestSequence(Cell ** matrix, int matrix_size, Bonus * b, int bonus_size, int reqBSize, Move ** bestBuffer);
void seqValue(int pos, int ** sol, Bonus *bonus, int bonusSize, Move ** m, Cell ** matrix, int reqSize, int val, int * bestVal);
int getCurrSeqValue(Move ** m, Cell ** matrix, Bonus *b, int bonus_size, int req_size);
void bestSeq(int step, int direction, int *** usedCells, Move ** m, Cell ** matrix, int matrix_size, Bonus * b, int bonus_size, int * currBestValue, int reqSize, Move ** bestBuffer);

int main () {
    Cell ** matrix;
    Bonus * bonus_arr;
    int matrix_size, bonus_size, len, bestValue;
    Move * moves;
    readMatrix(&matrix, &matrix_size);

    readBonus(&bonus_arr, &bonus_size);
    printf("Inserire la lunghezza per cui cercare il percorso migliore:");
    scanf("%d", &len);


    moves = (Move *)malloc(len * sizeof(Move));
    if (moves == NULL) {
        perror("Errore di allocazione della memoria");
        exit(4);
    }
    bestValue = getBestSequence(matrix, matrix_size, bonus_arr, bonus_size, len, &moves);

    printf("La miglior sequenza di valore %d è:\n", bestValue);
    for(int i = 0; i < len; i++)
    {
        printf("%s ", matrix[moves[i].row][moves[i].col].hex);
    }

    freeBonus(bonus_arr, bonus_size);
    freeMatrix(matrix, matrix_size);
    free(moves);


}
void readMatrix(Cell *** matrix, int * matrix_size) {
    FILE * fp;
    int i, j;

    if ((fp = fopen("grid.txt", "r")) == NULL) {
        printf("Erorre nella lettura del file");
        exit(1);
    }
    fscanf(fp, "%d", matrix_size);
    *matrix = (Cell **) malloc ((*matrix_size) * sizeof(Cell*));
    if (*matrix == NULL) {
        perror("Errore di allocazione della memoria");
        exit(4);
    }
    for (i = 0; i < *matrix_size; i++) {
        (*matrix)[i] = (Cell *) malloc ((*matrix_size) * sizeof(Cell));
        if ((*matrix)[i] == NULL) {
            perror("Errore di allocazione della memoria");
            exit(4);
        }
        for(j= 0; j < *matrix_size; j++) {
            fscanf(fp, "%s", ((*matrix)[i][j]).hex);
        }
    }
    fclose(fp);
}

void readBonus(Bonus ** bonus_arr, int * bonus_size) {
    FILE * fp;
    int i,j;
    int num_token, value;
    char tok_seq[100];
    if ((fp = fopen("bonus.txt", "r")) == NULL) {
        printf("Errore");
        exit(1);
    }
    fscanf(fp, "%d", bonus_size);
    *bonus_arr = (Bonus *)malloc(*bonus_size * sizeof(Bonus));
    if (*bonus_arr == NULL) {
        perror("Errore di allocazione della memoria");
        exit(4);
    }

    for( i = 0; i < *bonus_size; i++) {
        fscanf(fp, "%d %d", &num_token, &value);
        (*bonus_arr)[i].num_token = num_token;
        (*bonus_arr)[i].value = value;
        (*bonus_arr)[i].seq = (Cell *)malloc(num_token * sizeof(Cell));
        if ((*bonus_arr)[i].seq == NULL) {
            perror("Errore di allocazione della memoria");
            exit(4);
        }
        for(j = 0; j < (*bonus_arr)[i].num_token; j++)  {
            fscanf(fp, "%s", (*bonus_arr)[i].seq[j].hex);
        }
        // leggo la token sequence e i valori e li salvo all'interno dell'array
    }
    fclose(fp);
}

void freeMatrix(Cell ** matrix, int matrix_size) {
    for(int i = 0; i < matrix_size; i++) {
        free(matrix[i]);
    }
    free(matrix);
}
void freeBonus(Bonus * bonus_arr, int  bonus_size) {
    for(int i = 0; i < bonus_size; i++) {
        free(bonus_arr[i].seq);
    }
    free(bonus_arr);
}

int ValidMove(Move fromM, Move toM) {
    if ((fromM.row == toM.row || fromM.col == toM.col) && !(fromM.row == toM.row && fromM.col == toM.col))
        return 1;
    else
        return 0;
}

int VerifyValidSequence(Move * moves, int movCnt) {
    int valid = 1, i;
    Move prevMove = moves[0];
    for(i = 1; i < movCnt && valid == 1; i++) {
        if (!ValidMove(prevMove, moves[i])) {
            valid = 0;
        }
        prevMove = moves[i];
    }
    return valid;
}

int getBestSequence(Cell ** matrix, int matrix_size, Bonus * b, int bonus_size, int reqBSize, Move ** bestBuffer) {
// funzione wrapper per le chiamate ricorsive
    int bestValue = 0, i;
    Move * m;
    int ** usedCells;

    m = (Move *)malloc(reqBSize * sizeof(Move *));
    if (m == NULL) {
        perror("Errore di allocazione della memoria");
        exit(4);
    }

    usedCells = (int **)calloc(reqBSize, sizeof(int *));
    if (usedCells == NULL) {
        perror("Errore di allocazione della memoria");
        exit(4);
    }
    for(i = 0; i < reqBSize; i++) {
        usedCells[i] = (int *)calloc(reqBSize, sizeof(int));
        if (usedCells[i] == NULL) {
            perror("Errore di allocazione della memoria");
            exit(4);
        }
    }

    m[0].row = 0;
    m[0].col = 0;
    usedCells[0][0] = 1;
    bestSeq(1, 1, &usedCells, &m, matrix, matrix_size, b, bonus_size, &bestValue, reqBSize, bestBuffer);

    free(m);
    for(i = 0; i < reqBSize; i++)
        free(usedCells[i]);
    free(usedCells);

    return bestValue;
}

void seqValue(int pos, int ** sol, Bonus *bonus, int bonusSize, Move ** m, Cell ** matrix, int reqSize, int val, int * bestVal) {
    int i, j, firstPos = -1;

    if (pos >= bonusSize) {
        if (val > *bestVal) {
            *bestVal = val;
        }
        return;
    }

    for (i = 0, j = 0; i < reqSize && j < bonus[pos].num_token;i++) {
        if (strcmp(matrix[(*m)[i].row][(*m)[i].col].hex, bonus[pos].seq[j].hex) == 0 && (*sol)[i] == 0) {
            j++;
            if(firstPos == -1)
                firstPos = i;
        } else {
            i -= j;
            j = 0;
            firstPos = -1;
        }
    }
    if (j == bonus[pos].num_token) {
        // Provo a prenderlo
        for(i = 0; i < bonus[pos].num_token - 1; i++) {
            (*sol)[firstPos + i] = 1;
        }
        val += bonus[pos].value;

        seqValue(pos+1,sol,bonus,bonusSize,m,matrix,reqSize,val,bestVal);

        // lo libero
        for(i = 0; i < bonus[pos].num_token - 1; i++) {
            (*sol)[firstPos + i] = 0;
        }
        val -= bonus[pos].value;
    }

    // lo chiamo senza averlo preso
    seqValue(pos+1,sol,bonus,bonusSize,m,matrix,reqSize,val,bestVal);
}

int getCurrSeqValue(Move ** m, Cell ** matrix, Bonus *bonus, int bonus_size, int req_size) {
// Qui posso supporre che la sequenza sia valida in quanto ho usato il pruning sulle richieste precedenti
    int i = 0;
    int bestVal = 0;
    int * sol = calloc(req_size, sizeof(int));

    seqValue(0,&sol, bonus, bonus_size, m, matrix,req_size,0,&bestVal);
    free(sol);
    return bestVal;
}

void bestSeq(int step, int direction, int *** usedCells, Move ** m, Cell ** matrix, int matrix_size, Bonus * b, int bonus_size, int * currBestValue, int reqSize, Move ** bestBuffer) {
    int c, r, currValue = 0, i;
    if (step > reqSize - 1) {
        currValue = getCurrSeqValue(m, matrix, b, bonus_size, reqSize);
        if (currValue > *currBestValue) {
            for (i = 0; i < reqSize; i++) {
                (*bestBuffer)[i].row = (*m)[i].row;
                (*bestBuffer)[i].col = (*m)[i].col;
            }
            *currBestValue = currValue;
        }
        return;
    }

    // definisco che mi muoverò sulle righe, quindi fisso la colonna
    if(direction) {
        c = (*m)[step - 1].col;
        for (r = 0; r < matrix_size; r++) {
            if ((*usedCells)[r][c] == 0) {
                (*m)[step].col = c;
                (*m)[step].row = r;
                (*usedCells)[r][c] = 1;
                if (VerifyValidSequence(*m, step + 1))
                    bestSeq(step + 1, 0, usedCells, m, matrix, matrix_size, b, bonus_size, currBestValue, reqSize,
                            bestBuffer);
                (*usedCells)[r][c] = 0;
            }
        }
    } else {
        r = (*m)[step - 1].row;
        for (c = 0; c < matrix_size; c++) {
            if ((*usedCells)[r][c] == 0) {
                (*m)[step].col = c;
                (*m)[step].row = r;
                (*usedCells)[r][c] = 1;
                if (VerifyValidSequence(*m, step + 1))
                    bestSeq(step + 1, 1, usedCells, m, matrix, matrix_size, b, bonus_size, currBestValue, reqSize,
                            bestBuffer);
                (*usedCells)[r][c] = 0;
            }
        }
    }
}