#include <stdio.h>
#include "graph.h"

int main() {
    //il più corto (cardinalità minima) ma più costoso (peso maggiore)
    /*
     * grafo 1 è DAG , grafo 2 no , grafo 3 sì, grafo 4 no*/
    setbuf(stdout, 0);
    graph G;
    FILE *in;
    edge **archi, **soluzione; //vettore di puntatori
    if ((in=fopen("../grafo4.txt" ,"r"))==NULL){
        printf("Errore nell'apertura del file di lettura\n");
    }
    int i, found=0, n, count=0;
    G=G_load(in);
    n=G_getHowManyEdge(G);
    archi=malloc(n*sizeof(edge*));
    soluzione=malloc(n*sizeof(edge*));
    //rimuovo arco e controllo se è dag, se lo è (torna ZERO), l'arco è un candidato e lo metto nell'insieme
    //e non cerco archi più lunghi
    if (G_dfs(G)==0) //se trovo arco back (torna 1) NON è un DAG (devo controllare torni zero)
       printf("Grafo è già un DAG\n");
    else {
        for (i = 1; i < n && !found; i++) {
            G_comb_sempl(0, G, archi, n, i, &found, soluzione, &count); //con pruning
        }
        //dopo aver generato tutti gli archi di lunghezza i-1  che rende il grafo un DAG (una volta uscita dal for)
        //cerco quello che ha lunghezza massima
        printf("Rimozione arco peso massimo di lunghezza minima:\n");
        G_print_solution(G, (i - 1), soluzione);
        printf("Peso: %d\n", count);
        G_DAGrts(G);
    }
    free(archi); free(soluzione);
    G_free(G);
    return 0;
}

