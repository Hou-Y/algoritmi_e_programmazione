#include<stdio.h>
#include<stdlib.h>
#include "ST.h"

#ifndef LAB9ES1_GRAPH_H
#define LAB9ES1_GRAPH_H

typedef struct  graph_s *graph;
typedef struct arco {int v; int w; int wt;} edge;

graph G_load(FILE *in);
void GRAPHinsertE(graph G, int id1, int id2, int wt, int *num);
int G_getHowManyEdge(graph G);
void G_comb_sempl(int pos, graph val, edge **sol, int n, int k, int *found, edge **final, int *currmax);
void GRAPHremoveE(graph G, int id1, int id2);
void GRAPHprint(graph G);
graph G_init(int vert);
int G_dfs(graph G);
int dfsr(graph G, int w, int *time, int *pre, int *post);
int G_better(edge **sol, int k);
void G_print_solution(graph G, int i, edge **soluzione);
void G_DAGrts(graph G);
void G_free(graph G);
int G_max_path(graph D, int ts, int *index, int *dist, int i);
void findSOURCE(int *source, graph D);
void GRAPHreinsertE(graph G, int id1, int id2, int wt, int *num);

void fakeRemoveEDGE(graph G, edge e);
#endif //LAB9ES1_GRAPH_H