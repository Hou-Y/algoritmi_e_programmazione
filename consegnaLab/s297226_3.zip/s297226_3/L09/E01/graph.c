
#include "graph.h"

struct graph_s{ int V; int E; int **madj; edge *edgelist; ST st ;};

static int **MATRIXint(int righe, int col, int val);
static edge EDGEcreate(int v, int w, int wt);
static void reinsertE(graph G, edge e);
static void insertE(graph G, edge e);
static void  removeE(graph G, edge e);
static void TSdfsR(graph D, int v, int *ts, int *pre, int *time);

static void insertE(graph G, edge e) {
    int v = e.v, w = e.w, wt = e.wt;
    G->madj[v][w] = wt;
    //G->madj[w][v] = wt;
    //abbiamo un grafo ORIENTATO
    G->edgelist[G->E]=e;
    //quando inserisco modifico anche la edgelist, devi fare una funzione che non lo tocchi altrimenti rischi questi errori
    //rischi che un valore sovrascrivi quello vecchio
}

static edge EDGEcreate(int v, int w, int wt) {
    edge e;
    //v= indice del primo nodo
    //w= indice del secondo nodo (vertice di arrivo!)
    e.v = v; e.w = w; e.wt = wt;
    return e;
}

static int **MATRIXint(int righe, int col, int val){
    int i,j;
    int **t=malloc(righe * sizeof(int *));
    for(i=0; i<righe; i++)
        t[i]=malloc(col*sizeof(int));
    for(i=0; i<righe; i++)
        for(j=0; j<col; j++)
            t[i][j]=val;
    return t;
}

static void reinsertE(graph G, edge e){
    int v = e.v, w = e.w, wt = e.wt;
    G->madj[v][w] = wt;
    //così la edgelist non viene toccata e non rischio di sovrascrivere valori
}

graph G_init(int vert){
    graph G=malloc(sizeof *G);
    G->V=vert;
    G->E=0;
    G->edgelist=malloc(1*sizeof(edge));
    G->madj=MATRIXint(G->V,G->V,0);
    return G;
}

graph G_load(FILE *in){
    graph G;
    int i, wt, id1, id2, vert;
    int num=1;
    char tmp[MAX+1], tmp1[MAX+1];
    fscanf(in, " %d ", &vert);
    G=G_init(vert);
    G->st=STinit(G->V);
    for(i=0; i<G->V; i++){
        fscanf(in, "%s", tmp);
        STinsert( tmp, G->st, i);
        //printf(" %s  hei\n", tmp);
    }

    while((fscanf(in, "%s %s %d", tmp, tmp1, &wt))==3){
        id1 = STsearch(G->st, tmp);
        id2 = STsearch(G->st, tmp1);
        if(id1>=0 && id2>= 0)
            GRAPHinsertE(G, id1, id2, wt, &num);
    }
    return G;
}

void GRAPHprint(graph G){
    int i, j;
    for(i=0; i<G->V; i++){
        for(j=0; j<G->V; j++){
            printf(" %d", G->madj[i][j]);
        }
        printf("\n");
    }
}

void GRAPHinsertE(graph G, int id1, int id2, int wt, int *num){
    if(G->E >= *num){
        *num=*num*2;
        G->edgelist=realloc(G->edgelist, *num*sizeof(edge));
    }
    insertE(G, EDGEcreate(id1, id2, wt));
    G->E++;
}

void GRAPHreinsertE(graph G, int id1, int id2, int wt, int *num){
    reinsertE(G, EDGEcreate(id1, id2, wt));
    G->E++;
}

int G_getHowManyEdge(graph G){
    return G->E;
}

int G_dfs(graph G){
    int v, time=0, *pre, *post;
    pre = malloc(G->V * sizeof(int));
    post = malloc(G->V * sizeof(int));
    for(v=0; v<G->V; v++){
        pre[v]=-1; post[v]=-1; //inizializzazione
    }
    if(dfsr(G, 0, &time, pre, post)) //uso direttamente il nodo come partenza e controllo se ci sono back
        return 1;
    for(v=0; v<G->V; v++){ //se ci sono nodi ancora non scoperti
        if(pre[v]==-1 && dfsr(G, 0, &time, pre, post)) //per ogni dopo da scoprire controllo i back
            return 1;
    }
    free(pre); free(post);
    return 0;
}

int dfsr(graph G, int w, int *time, int *pre, int *post){
    int i;// v;
    pre[w]=(*time)++;
    for (i=0; i<G->V;i++){
        if (G->madj[w][i] >0){
            if(pre[i]==-1){ //se non ho ancora scoperto il nodo
                if(dfsr(G, i, time, pre, post))//continuo con l'esplorazione
                    return 1; //se una ricorsione interna ha trovato un back propaga la soluzione
            }
            else{
                //v=i;
                if (post[i]==-1) //altrimenti, se il nodo è stato già scoperto e ha post ==-1
                    return 1; //significa che ho un arco back, ritorna 1
            }
        }

    }
    post[w]=(*time)++;
    return 0;
}

void G_comb_sempl(int pos, graph val, edge  **sol, int n, int k, int *found, edge **final, int *currmax){
    int i, altr, dummy;
    if (pos >= k) {
        for(i=0; i<k; i++)
            GRAPHremoveE(val, (sol[i]->v), (sol[i]->w));
        //ciò a cui punta l'iesimo elemento nel vettore di puntatori sol
        if(G_dfs(val)==0){ //usando la dsf modificata che torna 0 se è un DAG
            *found=1;
            altr=G_better(sol, k);
            if(altr > *currmax){
                *currmax=altr;
                for (i=0; i<k; i++)
                    final[i]=sol[i];
            }
        }
        for(i=0; i<k; i++){
            dummy=val->E+1;
            GRAPHreinsertE(val, (sol[i]->v), (sol[i]->w), sol[i]->wt, &dummy );
        }
        // l'ultimo elemento è un dummy value dentro all'insertE, sono sicura che il numero allocato è maggiore
        //del numero di nodi, la parte di controllo non serve più, uso quindi un valore che
        // non farà allocare più edge
        return;
    }
    for (i=0; i<n; i++) {
            sol[pos] = &(val->edgelist[i]);
            G_comb_sempl(pos+1, val, sol, n, k, found, final, currmax);
        }

}

int G_better(edge **sol, int k){
    int i, sum=0;
    for(i=0; i<k; i++){
        sum+=sol[i]->wt;
    }
    return sum;
}

void GRAPHremoveE(graph G, int id1, int id2) {
    removeE(G, EDGEcreate(id1, id2, 0));
    G->E--;
}

static void  removeE(graph G, edge e) {
    int v= e.v, w= e.w;
    G->madj[v][w] = 0;
}

/*void removeEDGEVect(graph G, edge e){
    int i, j, gotcha=0;
    for(i=0; i<G->E && !gotcha; i++){
        if(G->edgelist[i].v == e.v && G->edgelist[i].w == e.w && G->edgelist[i].wt == e.wt){
            gotcha=1;
            for(j=i; j<G->E-1; j++)
                //G->edgelist[j+1]=G->edgelist[j];
                G->edgelist[j]=G->edgelist[j+1]; //questa sarebbe la versione corretta ma sembra sporchi cose
        }
    }
    G->E--;
}*/

void fakeRemoveEDGE(graph G, edge e){
    int i, gotcha=0;
    for(i=0; i<G->V && !gotcha; i++){
        if(G->edgelist[i].v == e.v && G->edgelist[i].w == e.w && G->edgelist[i].wt == e.wt){
            gotcha=1;
            G->edgelist[i].wt=-1; //se ha peso negativo non esiste
        }
    }
}

void G_print_solution(graph G, int i, edge **soluzione){
    int j;
    for(j=0; j<i; j++){
        printf("rimosso arco da %s a %s \n", STsearch_getname(G->st,soluzione[j]->v), STsearch_getname(G->st,soluzione[j]->w) );

        fakeRemoveEDGE(G, *soluzione[j] );
        removeE(G, *soluzione[j]);
    }
}

int G_max_path(graph D, int ts, int *index, int *dist, int i){
    //meglio guardare per ogni vertice che guardare per ogni arco nella edgelist e ripetere
    int v,j, w;
    for (v=0; v < D->V; v++)//devo resettare a ogni iterazione
        dist[v] = -1;

    dist[ts]=0;
    for(v=i; v < D->V; v++){
            w = index[v];
                if(dist[w]!=-1){
                    for (j=0; j<D->V; j++) { //funziona ma è ridondante (forse)
                        if ((dist[j]==-1 || dist[w]+D->madj[w][j] > dist[j]) && D->madj[w][j]!=-1)
                            dist[j] = dist[w]+D->madj[w][j];
                    }
                }
    }
    /*for(v=0; v < D->V; v++)
        printf("Dist %d   ", dist[v]);
    printf("\n");*/
    return dist[0];
}

void findSOURCE(int *source, graph D){
    int i, j;
    for (i=0; i < D->E; i++){ //uso edgelist
            if( D->edgelist[i].wt>0){
                source[D->edgelist[i].w]=-1;
                printf("nodo %s non e' sorgente\n", STsearch_getname(D->st, D->edgelist[i].w) );
            } //se trovo un singolo arco diretto verso il nodo, esso non è una sorgente

    }
}

void G_DAGrts(graph D) {
    int v, time = 0, *pre, *ts, *source;
    int max;
    int *dist;
    dist = malloc(D->V*sizeof(int));
    pre = malloc(D->V * sizeof(int));
    ts = malloc(D->V * sizeof(int));
    source= malloc(D->V * sizeof(int));
    //source ha in ogni casella un valore (-1 se NON è una fonte) e 1 se lo è, l'indice del source rappresenta il nodo
    // viene chiesto DALLA sorgente esplicitamente
    for (v=0; v < D->V; v++) {
        pre[v] = -1; ts[v] = -1; dist[v] = -1; source[v]=1;
    }
    for (v=0; v < D->V; v++)
        if (pre[v]== -1)
            TSdfsR(D, v, ts, pre, &time);
    //ordinamento topologico
    for (v=0; v < D->V; v++)
        printf("%s ", STsearch_getname(D->st, ts[v]));
    printf("\n");
    findSOURCE(source, D);
    for (v=0; v < D->V; v++){
        if(source[v]==1){
            max=G_max_path(D, ts[v], ts, dist, v);
            printf("distanza massima dalla sorgente %s e' lungo %d\n", STsearch_getname(D->st, v),  max);
            //individuo la sorgente se quella NON ha nodi entranti
        }

    }
    free(pre); free(ts); free(dist); free(source);
}

static void TSdfsR(graph D, int v, int *ts, int *pre, int *time) {
        int w;
        pre[v] = 0;
        for (w = 0; w < D->V; w++)
            if (D->madj[w][v] != 0){
                if (pre[w] == -1)
                    TSdfsR(D, w, ts, pre, time);
            }
        ts[(*time)++] = v;
    }

void G_free(graph G){
    int i;
    for (i=0; i<G->V; i++)
        free(G->madj[i]);
    free(G->madj);
    STfree(G->st);
    free(G);
}