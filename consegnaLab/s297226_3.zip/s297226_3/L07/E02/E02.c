#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MULTIPLY 8

typedef enum{
    spalle, frontale
}direzione;

typedef enum{
    false, true
}bool;

typedef enum{
    transizione, indietro, avanti
}tipologia;

typedef struct diag_s{
    char *nome; //da freeare
    tipologia tipo;
    direzione ingresso;
    direzione uscita;
    bool preceduto;
    bool isfinal;
    float valore;
    int difficulty;
}element;

typedef struct diag_sin{
    int list[5];
    float punteggio;
    int difficulty;
    int quanti;
    //meglio togliere quanti elementi ci sono e usare semplicemente un -1
} diag;

void read_element(element **diag, int *N);
void wrap_disp(int pos, diag **tutto, element* ele_list, int *maxn, int N, int DD, int *count, diag *temp);
//rendere la funzione sopra un void
int reallocdiag(diag **tutto, int maxn);
int check(int pos, int indice, element* ele_list, diag *temp);
void disp_diag(int pos, int num_diag, diag* tutto, diag sol[], int DP, int lim_diag, diag templist[], element *ele_list, float *greater);
int list_check(diag templist[3], int lim_diag, element *ele_list);
void stampaDiag_list(diag *sol, element *ele_list, int num_diag, int DD, int DP, float max);
void stampaDiag(diag *sol, element *ele_list, int i);
float greater_than_sol(diag templist[], diag sol[], int DP, element * ele_list, int greater);
//void multiply(diag **tutto, int  num_diag, element *ele_list);
void free_ele_list(element *ele_list, int num_diag);

int main(int argc, char* argv[]){
    setbuf(stdout, 0);
    diag sol[3], templist[3]; //3 diagonali con al max 5 elementi ( indice)
    element *ele_list; //da freeare
    diag *tutto;//da freeare
    diag temp;
    int N, DD, DP, i, j;
    float max;
    FILE *b_in;
    int maxn=1, num_diag; //quante diagonali ho
    read_element(&ele_list, &N );
    /*for(i=0; i<5; i++)
        tutto->list[i]=-1;*/
    //nuovi malloc e azzeramento in un'unica funzione
    if ((b_in=fopen("../boundary.txt","r"))==NULL){
        printf("Errore nell'apertura del file di lettura\n");
    }
    while (fscanf(b_in, " %d %d", &DD, &DP)==2){
        max=0; num_diag=0;
        tutto=(diag*)malloc(maxn*sizeof(diag)); //alloca l'elemento in posizione 0
        tutto->difficulty=tutto->quanti= temp.difficulty=temp.quanti=0;
        tutto->punteggio=temp.punteggio=0.0; //dove sarebbe il double?
        //inizializzazione
        wrap_disp(0, &tutto, ele_list, &maxn, N, DD, &num_diag, &temp); //generazioni di tutte le diagonali
        //multiply(&tutto, num_diag, ele_list);
        /*for(j=0; j<num_diag;j++){
            printf("REAL: ");
            for(i=0;  i<tutto[j].quanti; i++)
                printf(" %s %.3f", ele_list[(tutto)[j].list[i]].nome, ele_list[(tutto)[j].list[i]].valore);
            printf(" %d %.2f \n",(tutto)[j].difficulty,  (tutto)[j].punteggio );
        }*/

        for(i=0; i<3; i++){
            sol[i].punteggio=0.0; sol[i].difficulty=0;
        }

        disp_diag(0, num_diag, tutto, sol, DP, 3, templist, ele_list, &max);
        stampaDiag_list(sol, ele_list, 3, DD, DP, max);
        //freetutto(); freenome(),
        free(tutto);

    }
    free_ele_list(ele_list, N);
    /*for(i=0; i<3; i++)
        free(sol[i]);*/
    return 0;
}

void stampaDiag(diag *sol, element *ele_list, int i){
    int j;
    for(j=0; j<sol[i].quanti; j++)
        printf(" %s %.3f %d ", ele_list[sol[i].list[j]].nome, ele_list[sol[i].list[j]].valore, ele_list[sol[i].list[j]].difficulty);
}

void stampaDiag_list(diag *sol, element *ele_list, int num_diag, int DD, int DP, float max){
    int i;
    int totdif=0;
    for(i=0; i<num_diag; i++){
        totdif+=sol[i].difficulty;
    }
    printf("---Test case---\n DD= %d   DP= %d  TOT=%.3f  totdiff: %d\n", DD, DP, max, totdif);
    for(i=0; i<num_diag; i++){
        printf("DIAG #%d ", i);
        stampaDiag(sol, ele_list, i);
        printf("\n");
    }
}

int getdifficulty(diag templist[], int pos){
    int i, sum=0;
    for(i=0; i<=pos; i++)
        sum+=templist[i].punteggio;
    return sum;
}



void multiply(diag **tutto, int  num_diag, element *ele_list){
    int i;
    for(i=0; i<num_diag; i++){
        if(ele_list[ (*tutto)[i].list[((*tutto)[i].quanti)-1] ].valore>=MULTIPLY){
            (*tutto)[i].punteggio=1.5*(*tutto)[i].punteggio;
            //printf("\n %.3f | \n", (*tutto)[i].punteggio);
        }
    }

}

int list_check(diag templist[3], int lim_diag, element *ele_list){
    //uno in avanti, uno indietro, e due elementi acrobatici in sequenza
    int vanti=0, dietro=0, doppio=0, i, j; //non copia mai in sol, non ritorna mai 1
    for(i=0; i<lim_diag; i++){
        for(j=0; j<templist[i].quanti; j++){
            if(ele_list[templist[i].list[j]].tipo==avanti)
                vanti=1;
            if(ele_list[templist[i].list[j]].tipo==indietro)
                dietro=1;
            if(ele_list[templist[i].list[j]].tipo!=transizione && j<templist[i].quanti-1 && ele_list[templist[i].list[j+1]].tipo!=transizione)
                doppio=1;

        }
    }
    if(vanti && dietro && doppio)
        return 1;
    return 0;
}

void free_ele_list(element *ele_list, int N){
    int i;
    for(i=0; i<N; i++){
        free(ele_list[i].nome);
    }
    //free(ele_list);
}

float greater_than_sol(diag templist[], diag sol[], int DP, element *ele_list, int greater){
    int tempdiff=0, i, check=0;
    //float solsum=0.0, tempsum=0.0;
    float tempsum=0.0;
    for(i=0;i<3; i++){
        //tempsum+=templist[i].punteggio;
        //solsum+=sol[i].punteggio;
        tempdiff+=templist[i].difficulty;
        if(ele_list[templist[i].list[ (templist[i].quanti)-1 ] ].difficulty>= MULTIPLY && !check){
            tempsum+=1.5*templist[i].punteggio;
            check=1;
        }
        else
            tempsum+=templist[i].punteggio;
    }

    if(tempdiff <= DP && tempsum>=greater)
        return tempsum;
    return -1;
}

void disp_diag(int pos, int num_diag, diag* tutto, diag sol[], int DP, int lim_diag, diag templist[], element *ele_list, float *greater){
    int i, list_ch=0;
    float is_greater;
    if(pos>=lim_diag){
        //il valore massimo è già dentro alla struct diag
        is_greater=greater_than_sol(templist, sol, DP, ele_list, *greater);
        list_ch=list_check(templist, lim_diag, ele_list);
        if(list_ch>0 && is_greater>=0){
            *greater=is_greater;
            //printf("NEW; %.3f\n", *greater);
            for(i=0; i<lim_diag; i++){
                sol[i]=templist[i];
            }
            //copia in sol
        }
        return;
    }
    for(i=0; i<num_diag; i++){
        //if(getdifficulty(templist, pos)+tutto[i].difficulty>DP){
        templist[pos]=tutto[i];
        disp_diag(pos+1, num_diag, tutto, sol, DP, lim_diag, templist, ele_list , greater);
        //il templist verrà sovrascritto
        //}
    }
}


int check(int pos, int indice, element* ele_list, diag *temp){
    if(pos==0 && ele_list[indice].preceduto==false && ele_list[indice].ingresso!=spalle)
        return 2;
    if(pos>0 && ele_list[temp->list[pos-1]].isfinal==false && ele_list[temp->list[pos-1]].uscita==ele_list[indice].ingresso)
        return 1;
    return 0;
}

/*void copywhole(diag **tutto, diag *temp, int count){
    /*int i;
    (*tutto)[count].quanti=temp->quanti ;
    (*tutto)[count].difficulty=temp->difficulty ;
    (*tutto)[count].punteggio=temp->punteggio;
    for(i=0; i<temp->quanti; i++){
        (*tutto)[count].list[i]=temp->list[i];
    }
    (*tutto)[count]=*temp;
}*/

void wrap_disp(int pos, diag **tutto, element* ele_list, int *maxn, int N, int DD, int *count, diag *temp){
    int i, j, buono=0;

    if(pos>0){ //se ho almeno un singolo elemento
        for(j=0; j<pos;j++){ //posizione attuale
            if(ele_list[temp->list[j]].tipo!=transizione)
                buono=1;//ha almeno un elemento acrobatico
        }
        if(buono && temp->difficulty<=DD){
            //riallocazione se necessaria
            if(*count>=*maxn-1) //maxn 0x2 vuota segmentation fault
                *maxn=reallocdiag(tutto, *maxn);
            temp->quanti=pos; //posizione parte da zero
            //copia
            /*for(j=0; j<pos;j++)
                printf(" %s %d %.2f ", ele_list[temp->list[j]].nome, ele_list[temp->list[j]].difficulty, ele_list[temp->list[j]].valore);
            printf(" %d %.2f \n",temp->difficulty,  temp->punteggio );*/
            (*tutto)[*count]=*temp;
            /*for(j=0; j<pos;j++)
                printf(" %s ", ele_list[(*tutto)[*count].list[j]].nome);
            printf(" %d %.2f \n",(*tutto)[*count].difficulty,  (*tutto)[*count].punteggio );*/
            (*count)++;
        }
    }
    if (pos>=5)
        return;
    for(i=0; i<N;i++){
        if(check(pos, i, ele_list, temp)){
            temp->list[pos]=i;
            temp->difficulty+=ele_list[i].difficulty;
            temp->punteggio+=ele_list[i].valore;
            wrap_disp(pos+1, tutto, ele_list, maxn, N, DD, count, temp);
            temp->difficulty-=ele_list[i].difficulty;
            temp->punteggio-=ele_list[i].valore;
        }
    }
}

int reallocdiag(diag **tutto, int maxn){
    int j;
    j=maxn; //indice del primo elemento da allocare
    maxn=maxn*2;
    (*tutto)=realloc((*tutto), maxn*(sizeof(diag)));
    while(j<maxn){ //nuovo valore di maxn (quello moltiplicato per 2)
        //azzero solo le porzioni appena create di lista
        (*tutto)[j].difficulty=(*tutto)[j].quanti=0; (*tutto)[j].punteggio=0.0;
        /*for(i=0; i<5; i++)
            tutto[j].list[i]=-1;*/
        j++; //fino al primo elemento non allocato
    }
    return maxn;
}

void read_element(element **diag, int *N){
    FILE *in;
    int i;
    char tempname[100];
    if ((in=fopen("../elementi.txt","r"))==NULL){
        printf("Errore nell'apertura del file di lettura\n");
    }
    fscanf(in, " %d", N);
    (*diag)=(element*)malloc((*N) * sizeof(element));
    for(i=0; i<*N; i++){
        fscanf(in, " %s %d %d %d %d %d %f %d",
               tempname, //salvato
               &((*diag)[i].tipo),
               &(*diag)[i].ingresso,
               &(*diag)[i].uscita,
               &(*diag)[i].preceduto,
               &(*diag)[i].isfinal,
               &(*diag)[i].valore,
               &(*diag)[i].difficulty);
        (*diag)[i].nome=strdup(tempname);
    }
}



