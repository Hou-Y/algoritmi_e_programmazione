#ifndef LAB8_9_GRAFO_H
#define LAB8_9_GRAFO_H

//grafo NON orientato PESATO

#include <stdlib.h>
#include <stdio.h>
#include "ST.h"

typedef struct graph_st *graph_p;
typedef struct arco {int v; int w; int wt;} edge;
typedef struct node *link;
struct node { int v; int peso; link next; };

void GRAPHinit(int V, int E, graph_p G);
graph_p GRAPHload(FILE *fin);
void GRAPHinsertE(graph_p G, int id1, int id2, int wt);
link newNode(int v, int peso, link next);
void GRAPHprint(graph_p G);
void LISTload(graph_p G);
void Gshow_ordered(graph_p G);
int G_check_bymatrix(graph_p G);
int LIST_check_adj(graph_p G);
void G_free(graph_p G);
void LIST_free(link inizio);
void wrap_LIST_free(graph_p G);

#endif //LAB8_9_GRAFO_H
