
#ifndef LAB8_9_ST_H
#define LAB8_9_ST_H

#include <stdlib.h>
#include <stdio.h>

typedef struct symboltable *ST;

ST STinit(int maxN) ;
int STinsert(ST st, char* val, char *netname, int *V);
int STsearch(ST st, char* key) ;
void STnewtab_dim(ST st, int V);
char *STsearch_getname(ST st, int num_ord);
void STsort(ST st,int *ord);
void STfree(ST st);
void STfree(ST st);
int STcount(ST st);



#endif //LAB8_9_ST_H
