#include "grafo.h"
#define MAXC 30

struct graph_st{int V; int E; int **madj; link *ladj; ST tab;};
// V=vertici    E=archi     madj=matrice di adiacenza   tab=tabella di simboli
static int **MATRIXint(int righe, int col, int val);
static edge EDGEcreate(int v, int w, int wt);
static void insertE(graph_p G, edge e);

static void insertE(graph_p G, edge e) {
    int v = e.v, w = e.w, wt = e.wt;
    G->madj[v][w] = wt;
    G->madj[w][v] = wt;
}

static edge EDGEcreate(int v, int w, int wt) {
    edge e;
    //v= indice del primo nodo
    //w= indice del secondo nodo
    e.v = v; e.w = w; e.wt = wt;
    return e;
}

static int **MATRIXint(int righe, int col, int val){
    int i,j;
    int **t=malloc(righe * sizeof(int *));
    for(i=0; i<righe; i++)
        t[i]=malloc(col*sizeof(int));
    for(i=0; i<righe; i++)
        for(j=0; j<col; j++)
            t[i][j]=val;
    return t;
} //static function: funzione che può essere chiamata solo dal file in cui è presente (grafo.c)


void GRAPHinit(int V, int E, graph_p G){//massimo numero di vertici
        G->V = V;
        G->E = E; //sapendo a priori il numero degli archi non incremento di uno ad ogni edge aggiunta nell'EDGEcreate
        G->madj = MATRIXint(V+1, V+1, 0); //da deallocare
}

graph_p GRAPHload(FILE *fin){
    graph_p G = malloc(sizeof *G);
    //leggo 2 volte, prima leggo il numero di elementi poi rileggo per riempire la matrice delle adiacenze
    int E=0, i, id1, id2, wt, V=1;
    char label1[MAXC], label2[MAXC], netname1[MAXC], netname2[MAXC];

    G->tab = STinit(V); //inizializzo solo una parte di grafo
    while(fscanf(fin, "%s %s %s %s %d\n", label1, netname1, label2, netname2, &wt) == 5) {
        id1 = STsearch(G->tab, label1);
        id2 = STsearch(G->tab, label2);
        if(id1==-1){
            id1=STinsert(G->tab,label1, netname1, &V);
            G->V=id1;
        }
        if(id2==-1){
            id2=STinsert(G->tab,label2, netname2, &V);
            G->V=id2;
        }
        E++;
    }
    rewind(fin);
    STnewtab_dim(G->tab, G->V);
    GRAPHinit(G->V, E, G);
    for(i=0; i<E;i++){
        fscanf(fin, "%s %s %s %s %d\n", label1, netname1, label2, netname2, &wt);
        id1 = STsearch(G->tab, label1);
        id2 = STsearch(G->tab, label2);
        GRAPHinsertE(G, id1, id2, wt);
    }
    return G;
}

void GRAPHinsertE(graph_p G, int id1, int id2, int wt) {
    insertE(G, EDGEcreate(id1, id2, wt));
}

link newNode(int v, int peso, link next) {
    link x;
    x = malloc(sizeof *x);
    x->v = v;
    x->peso = peso;
    x->next = next;
    return x;
}

void LISTload(graph_p G){
    int v, w;
    G->ladj = calloc(G->V, sizeof(link));

    for (v=0; v<G->V; v++)
        for (w=0; w<G->V; w++)
            if (G->madj[v][w]>0) {
                G->ladj[v] = newNode(w, G->madj[v][w], G->ladj[v]);
                G->ladj[w] = newNode(v, G->madj[v][w], G->ladj[w]);
                //creo dei nodi due volte in quanto lista viene generata da matrice di adiacenza
            }
}

void GRAPHprint(graph_p G){
    int i, j;
    for(i=0; i<G->V; i++){
        for(j=0; j<G->V; j++){
            printf(" %d", G->madj[i][j]);
        }
        printf("\n");
    }
}

void Gshow_ordered(graph_p G){
    int i,j;
    int *ord = malloc(STcount(G->tab) * sizeof(int));
    //ord contiene gli indici relativo alle chiavi nella ST in ordine alfabetico
    STsort(G->tab,ord);
    for(i=0;i< STcount(G->tab);i++){
        printf("%s\n", STsearch_getname(G->tab,ord[i]));
        for(j=0;j< STcount(G->tab);j++){
            //if(G->madj[ord[i]][ord[j]]!=0 && i!=j){
            if(G->madj[ord[i]][ord[j]]!=0){
                printf("    %s\n", STsearch_getname(G->tab, ord[j]));
            }
        }
        printf("\n");
    }
    free(ord);
}

int G_check_bymatrix(graph_p G){
    char v1[MAXC], v2[MAXC], v3[MAXC];
    int id1,id2,id3;
    printf(" Scrivi i nomi dei tre vertici");
    scanf("%s %s %s", v1, v2, v3);
    id1=STsearch(G->tab, v1);
    id2=STsearch(G->tab, v2);
    id3=STsearch(G->tab, v3);
    if(id1<0 || id2<0 || id3<0)
        printf("Errore nell'input dei vertici, soluzione calcolata errata\n");
    else if(G->madj[id1][id2]!=0 && G->madj[id1][id3]!=0 && G->madj[id3][id2]!=0)
        return 1;
    return -1;
}

int LIST_check_adj(graph_p G){
    char v1[MAXC], v2[MAXC], v3[MAXC];
    int id1,id2,id3;
    int count=0;
    link i;
    printf(" Scrivi i nomi dei tre vertici");
    scanf("%s %s %s", v1, v2, v3);
    id1=STsearch(G->tab, v1);
    id2=STsearch(G->tab, v2);
    id3=STsearch(G->tab, v3);
    if(id1<0 || id2<0 || id3<0)
        printf("Errore nell'input dei vertici, soluzione calcolata errata\n");
    else{
        for(i=G->ladj[id1];i!=NULL;i=i->next){
            if(i->v==id2)
                count++;
        }
        for(i=G->ladj[id2];i!=NULL;i=i->next){
            if(i->v==id3)
                count++;
        }
        for(i=G->ladj[id3];i!=NULL;i=i->next){
            if(i->v==id1)
                count++;
        }
    }
    return count;
}

void wrap_LIST_free(graph_p G){
    int i;
    for(i=0; i<STcount(G->tab)-1; i++){
        if(G->ladj!=NULL)
            LIST_free(G->ladj[i]);
    }
}

void LIST_free(link inizio){
    link temp;
    while(inizio!=NULL){
        temp=inizio;
        inizio=inizio->next;
        free(temp);
    }
}

void G_free(graph_p G){
    int i;
    for (i=0; i<G->V; i++)
        free(G->madj[i]);
    free(G->madj);
    STfree(G->tab);
    free(G);
}
