
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ST.h"

struct symboltable { char **keys; char **subnet; int n_key; int tab_dim;};
//key al posto di a, n_key al posto di N, tab_dim al posto di M

ST STinit(int maxN) {
    ST st = malloc(sizeof(*st));
    st->n_key = 0;
    st->tab_dim = maxN ;
    if (st->tab_dim < 0)
        st = NULL;
    else {
        st->keys = malloc(maxN * sizeof(char*) );
        st->subnet = malloc(maxN * sizeof(char*) );
        //vettori di puntatori a char
    }
    return st;
}

int STsearch(ST st, char* key){
    int i;
    for (i = 0; i  < st->n_key; i++)
        if (st->keys[i]!=NULL && strcmp(key, st->keys[i])==0)
            return i;
    return -1;
}

int STinsert(ST st, char* val, char *netname, int *V){

    if(st->n_key == *V) {
        *V=*V*2;
        st->keys = realloc(st->keys, (*V) * sizeof(char *));
        st->subnet = realloc(st->subnet, (*V) * sizeof(char *));
    }
    st->keys[st->n_key] = strdup(val);
    st->subnet[st->n_key] = strdup(netname);
    st->n_key++;
    return st->n_key-1;
}

void STnewtab_dim(ST st, int V){
    st->tab_dim=V;
}

int STcount(ST st){
    return st->n_key;
}

char *STsearch_getname(ST st, int num_ord){
    return (st->keys[num_ord]);
}

void STsort(ST st,int *ord){
    //inserction sort
    int i,j, temp , n=STcount(st);
    for(i=0;i<n;i++)
        ord[i]=i;
    for(i = 1; i < n; i++) {
        temp=ord[i];
        j=i-1;
        while(j >= 0 && strcmp(st->keys[temp], st->keys[ord[j]])<0 ) {
                ord[j+1] = ord[j];
                j--;
            }
        ord[j+1]=temp;
    }
}

void STfree(ST st){
    int i;
    for (i=0; i<st->n_key; i++){
        free(st->keys[i]);
        free(st->subnet[i]);
    }
    free(st->keys);
    free(st->subnet);
    free(st);
}