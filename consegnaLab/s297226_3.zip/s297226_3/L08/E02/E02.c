#include <stdio.h>
#include "grafo.h"
#define N_SCELTE 6
#define LIM 30
#define DBG 0

enum { falso, vero };
typedef int bool;

void stampaMenu(char *scelte[], int *selezione){
    int i;
    printf("\nMENU'\n (Inserimento dati da file è richiesto per scelte del menù successive ad esso)\n");
    for(i=0;i<N_SCELTE;i++)
        printf("%2d > %s\n",i,scelte[i]);
    scanf(" %d",selezione);
}

int main(int argc, char **argv) {
    setbuf(stdout, 0);
    char *scelte[] = {
            "0:Uscita",
            "1:Inserimento dati da file e creazione matrice adiacenze",
            "2:Creazione lista di adiacenze",
            "3:Ordine alfabetico",
            "4:Verifica adiacenza a coppie dati 3 vertici da matrice adiacenze",
            "5:Verifica adiacenza a coppie dati 3 vertici da lista di adiacenze"
    };
    int selezione;
    FILE *fin;
    bool fineProgramma=falso;
    bool list_loaded=falso;
    int check_matrix,  check_l, i;

    //char nome[LIM]="../grafo.txt";
    char nome[LIM];
    graph_p G;

    do {
        stampaMenu(scelte, &selezione);
        switch (selezione) {

            case 0: {
                fineProgramma = vero;

            } break;

            case 1: {
                printf("Inserisci nome del file:\n");
                scanf("%s", nome);
                if ((fin=fopen(nome ,"r"))==NULL){
                    printf("Errore nell'apertura del file di lettura\n");
                }
                G=GRAPHload(fin);
                #if DBG
                GRAPHprint(G);
                #endif /* DBG */
            } break;

            case 2: {
                LISTload(G);
                list_loaded=vero;
            } break;

            case 3: {
                Gshow_ordered(G);
            } break;

            case 4: {
                check_matrix=G_check_bymatrix(G);
                if(check_matrix) printf(" Vertici adiacenti\n");
                else printf("Vertici non adiacenti\n");
            } break;

            case 5: {
                if(list_loaded==vero){
                    check_l=LIST_check_adj(G);
                    if(check_l==6) printf(" Vertici adiacenti\n");
                    else printf("Vertici non adiacenti\n");
                }
                else printf("Carica la lista delle adiacenze\n");

            } break;

            default:
                printf("Scelta non disponibile\n");
        }

    }while(!fineProgramma);
    if(list_loaded=vero)
        wrap_LIST_free(G);

    G_free(G);
    return 0;
}
