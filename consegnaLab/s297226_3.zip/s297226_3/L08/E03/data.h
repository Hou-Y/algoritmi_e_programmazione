#include <stdio.h>

#ifndef LAB8ES3_DATA_H
#define LAB8ES3_DATA_H
typedef struct data_s{int anno; int mm; int gg; int ora; int minu;}tempo;

void hourin(char *tdate, tempo *x);
void datein(char *tdate, tempo *x);
int tempo_compare(tempo curr , tempo k);

#endif //LAB8ES3_DATA_H
