
#include "titoli.h"
#include "quotaz.h"
#include <string.h>
#define MAXN 20

struct titolo_s {tempo data; int val; int n_trans;};

struct node {int n; char key[MAXN]; item title; BST Q; link next;};

link newNode(char tkey[], int tn, FILE *in){
    int j;
    char tdate[MAXN];
    link new=malloc(sizeof(struct node));
    item titolo=malloc(tn*sizeof(struct titolo_s));
    node tmp;
    strcpy(new->key, tkey);
    new->n=tn;
    new->Q=BSTinit();
    for(j=0; j<tn; j++){
        fscanf(in, " %s", tdate );
        datein(tdate, &(titolo[j].data));
        fscanf(in, " %s", tdate );
        hourin(tdate, &(titolo[j].data));
        //gli inserimenti sono in foglia
        //però z è un nodo fittizio
        fscanf(in, " %d %d", &titolo[j].val, &titolo[j].n_trans);
        tmp=BSTsearch(new->Q, titolo[j].data);
        if(tmp==NULL)
            BSTinsert_leafR(new->Q, titolo[j].data, titolo[j].val, titolo[j].n_trans );
        else
            BSTaddv(tmp, titolo[j].val, titolo[j].n_trans);
    }
    new->title=titolo;
    new->next=NULL;
    return new;
}

link insertNode(link node, link head){
    struct node *curr;
    if(head==NULL){
        return node;
    }
    else if(strcmp(node->key, head->key)<=0 ){
        node->next=head;
        return node;
    }
    for(curr=head; (curr!=NULL  && curr->next!=NULL && strcmp(node->key, curr->key)>0); curr=curr->next ){
        //printf("ey\n");
    }
    curr->next=node; //ultimo elemento
    return head;
}

link  readfile(FILE *in){
    link  head=NULL;
    int n, i, tn;
    char tkey[MAXN];
    fscanf(in, " %d", &n);
    for(i=0; i<n; i++){
        fscanf(in, " %s %d", tkey, &tn);
        head=insertNode(newNode(tkey, tn, in), head);
    }
    return head;
}


link searcht(char *tname, link T){
    link i;
//lista NON ordinata nonostante gli indici siano ordinati, conta come ordinata? accesso lineare
    for(i=T; i!=NULL ; i=i->next){
        if(strcmp(i->key, tname)==0){
            return i;
        }
    }
    return NULL;
}

void  wrap_search(link curr){
    float val;
    tempo giorno;
    node tmp;
    printf("inserire anno, mese e giorno come numeri distinti\n");
    scanf(" %d %d %d", &giorno.anno, &giorno.mm, &giorno.gg);
    tmp=BSTsearch(curr->Q, giorno);
    if(tmp==NULL)
        printf("Data non trovata\n");
    else{
        val=getQuotation(tmp);
        printf("Quotazione giornaliera: %.2f", val);
    }
}

void wrap_searchbydate(link curr){
    tempo start, fin;
    printf("inserire anno, mese e giorno come numeri distinti\n Data inizio\n");
    scanf(" %d %d %d", &start.anno, &start.mm, &start.gg);
    printf("Data fine\n");
    scanf(" %d %d %d", &fin.anno, &fin.mm, &fin.gg);
    BSTsearchRange(curr->Q, start, fin);
}

void  wrap_searchall(link curr){
    tempo start, fin;
    start.anno=0; start.mm=0; start.gg=0;
    fin=BSTmaxdate(curr->Q);
    BSTsearchRange(curr->Q, start, fin);
}

void wrap_balance(link curr, int s){
    float a=BSTcamminoExceed(curr->Q), b=BSTcamminoMin(curr->Q);
    if( a/b >=s)
        BSTbalance(curr->Q, s);
}
