#include <stdio.h>
#include<stdlib.h>
#include "titoli.h"

typedef enum {acqu, ric_l, ric_bst, ric_q_t, ric_q, balance}comand;

int main(){
    setbuf(stdout, 0);
    FILE *in;
    char filename[MAX]="../F3.txt";
    char tname[MAX];
    int scelta, fine=0, s;
    link T, curr=NULL;
    while(!fine){
        printf("scrivi il numero per selezionare:\n");
        printf("0: acquisizione del contenuto da file\n1: ricerca di un titolo azionario\n2:quotazione in data\n");
        printf("3: quotazione max e min entro un range di date\n4:quotazione massima e minima totale\n");
        printf("5:bilanciamento quotazioni\nOgni altro numero per terminare\n");
        scanf(" %d", &scelta);
        switch(scelta){
            case acqu :{
                printf("nome file:");
                //scanf("%s", filename);
                in=fopen(filename, "r");
                T=readfile(in);
            }break;

            case ric_l :{
                printf("nome titolo:");
                scanf("%s", tname);

                curr=searcht(tname, T);
                if(curr!=NULL) printf("Titolo esistente\n");
                else printf("Non trovato\n");
            }break;

            case ric_bst :{
                if(curr==NULL) printf("Seleziona titolo\n");

                else wrap_search(curr);
            }break;

            case ric_q_t :{
                if(curr==NULL) printf("Seleziona titolo\n");
                else wrap_searchbydate(curr);
            }break;

            case ric_q :{
                //caso particolare di quello sopra
                if(curr==NULL) printf("Seleziona titolo\n");
                else wrap_searchall(curr);//chiamerà la stessa funzione che chiama searchdate
            }break;

            case balance:{
                printf("Scrivi limite lunghezza tra cammino piu' lungo e cammino piu' corto\n");
                scanf(" %d", &s);
                if(curr==NULL) printf("Seleziona titolo\n");
                else wrap_balance(curr,s);
            }break;

            default:{
                fine=1;
            }
        }
    }
    return 0;
}

