#include "data.h"
#include <stdlib.h>

#ifndef LAB8ES3_QUOTAZ_H
#define LAB8ES3_QUOTAZ_H

typedef struct quo_s {tempo data; int sum_v; int n_title;} quo;

typedef struct BST_s *BST;
typedef struct BSTnode* node;

BST BSTinit( );
quo ITEMsetNull();
node BSTsearch(BST bst, tempo k);
void BSTinsert_leafR(BST bst, tempo data , int val , int n_trans );
void BSTaddv(node tmp, int val, int ntrans);
float getQuotation(node h);
void BSTsearchRange(BST bst, tempo start, tempo fin);
tempo BSTmaxdate(BST bst);
void BSTbalance(BST bst, int s);
int BSTcamminoExceed(BST bst);
int BSTcamminoMin(BST bst);


#endif //LAB8ES3_QUOTAZ_H
