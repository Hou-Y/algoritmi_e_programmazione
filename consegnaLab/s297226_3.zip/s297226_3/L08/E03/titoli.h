
#ifndef LAB8ES3_TITOLI_H
#define LAB8ES3_TITOLI_H
#include <stdlib.h>
#include<stdio.h>
#include "quotaz.h"
#include "data.h"

#define MAX 20

typedef struct titolo_s *item;

typedef struct node *link;

link readfile(FILE *in);
link searcht(char *tname, link T);
link newNode(char tkey[], int tn,FILE *in);
void wrap_search(link curr);
void wrap_searchbydate(link curr);
void  wrap_searchall(link curr);
void wrap_balance(link curr,int s);

#endif //LAB8ES3_TITOLI_H
