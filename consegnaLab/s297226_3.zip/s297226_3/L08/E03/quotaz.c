#include"quotaz.h"

struct BST_s {node root; node z; } ;
struct BSTnode { quo item; node l; node r; int N;} ;

static node NEW(quo item, node l, node r,int N);
static node insertR(node h, quo x, node z);
static node searchR(node h, tempo k, node z);
static void findTempMax(node h, node z, tempo *start);
static node rotL(node h);
static node rotR(node h);
static node partR(node h, int r, node z);
static void searchRange(node root, tempo start,tempo fin, float *qmin, float *qmax, node z);
static node balanceR(node h, node z, int s);
static int camminoExceed(node root , node z, int num);
static int max(int a, int b, int c);
static int camminoMin(node root , node z, int num);
static int min(int a, int b, int c);


static node NEW(quo item, node l, node r, int N) {
    node x = malloc(sizeof *x);
    x->item = item;
    x->l = l; x->r = r; x->N=N;
    return x;
}

static node insertR(node h, quo x, node z) {
    if (h == z)
        return NEW(x, z, z, 1);
    if (tempo_compare( x.data,h->item.data)==-1)
        h->l = insertR(h->l, x, z);
    else
        h->r = insertR(h->r, x, z);
    h->N++;
    return h;
}
void BSTinsert_leafR(BST bst, tempo data , int val , int n_trans ) {
    quo x; x.data=data; x.sum_v=val*n_trans;  x.n_title=n_trans;
    bst->root = insertR(bst->root, x, bst->z);
}

BST BSTinit( ) {
    BST bst = malloc(sizeof *bst) ;
    bst->root= ( bst->z = NEW(ITEMsetNull(), NULL, NULL, 0));
    return bst;
}

quo ITEMsetNull(){
    quo newquo;
    newquo.n_title=newquo.sum_v=0;
    return newquo;
}

node BSTsearch(BST bst, tempo k) {
    return searchR(bst->root, k, bst->z);
}

static node searchR(node h, tempo k, node z) {
    int cmp;
    if (h == z)
        return NULL;
    cmp=tempo_compare(h->item.data, k);
    if (cmp == 0)
        return h;
    if (cmp==-1)
        return searchR(h->l, k, z);//search left side
    return searchR(h->r, k, z);//search right side
}

void BSTsearchRange(BST bst, tempo start, tempo fin){
    //come una normale visita ma controlli se il nodo è dentro il range e se lo è
    //guarda il valore della sua quotazione, se è minore del minimo aggiorna il minimo, se è maggiore del massimo aggiorna il massimo

    float qmin=getQuotation(bst->root), qmax=0;
    //il minimo viene posto come un elemento casuale, se nel BST ci sono elementi minori verrà aggiornato
    searchRange(bst->root, start, fin, &qmin, &qmax, bst->z);
    printf("Quotazione minima: %.2f\n Quotazione massima : %.2f\n", qmin, qmax);

}

static void searchRange(node root, tempo start,tempo fin, float *qmin, float *qmax, node z){
    float qt;
    //non ha senso scendere in alcuni parti se non sono in range
    if(root==z)
        return;
    if (tempo_compare(root->item.data, fin )>=0)
        searchRange(root->l, start, fin, qmin, qmax, z);
    if( tempo_compare(root->item.data, fin)<=0 && tempo_compare(root->item.data, start)>=0){ //dopo l'inizio e prima della fine
        qt=getQuotation(root);
        if(qt<=*qmin)
            *qmin=qt;
        if(qt>=*qmax)
            *qmax=qt;
    }
    if (tempo_compare(root->item.data, start )<=0)
        searchRange(root->r, start, fin, qmin, qmax, z); //scendo a dx se il nodo attuale è dentro il range oppure se
    //lo start è più piccolo del range

}

void BSTaddv(node tmp, int val, int ntrans){
    tmp->item.sum_v+=val*ntrans; //media pesata
    //tmp->item.sum_v+=val; //media
    tmp->item.n_title+=ntrans;
}

float getQuotation(node h){
    return ((float)h->item.sum_v/(float)h->item.n_title);
}

tempo BSTmaxdate(BST bst){
    tempo start;
    start.anno=0; start.mm=0; start.gg=0;
    findTempMax(bst->root, bst->z, &start);
    return start;
}

static void findTempMax(node h, node z, tempo *start){
    if (h == z)
        return;
    if(tempo_compare(h->item.data, *start)>=0)
        *start=h->item.data;
    findTempMax(h->r, z, start);//search right side
}

static node rotL(node h) {
    node x = h->r;
    h->r = x->l;
    x->l = h;
    x->N = h->N;
    h->N = 1;
    h->N += (h->l) ? h->l->N : 0;
    h->N += (h->r) ? h->r->N : 0;
    return x;
}

static node rotR(node h) {
    node x = h->l;
    h->l = x->r;
    x->r = h;
    x->N = h->N;
    h->N = 1;
    h->N += (h->l) ? h->l->N : 0;
    h->N += (h->r) ? h->r->N : 0;
    return x;
}


static node partR(node h, int r, node z){
    int i;
    if(h==z || h->l==z)
        return h;
    i=h->l->N;
    if (i>r){
        h->l= partR(h->l, r,z);
        h=rotR(h);
    }
    if (i<r){
        h->r= partR(h->r, r,z);
        h=rotL(h);
    }
    return h;
}

static node balanceR(node h, node z, int s) {
    int r;
    if (h == z) //invece di h ho bisogno di s volte bh
        return z;
    r = (h->N+1)/2-1;
    h = partR(h, r, z);
    h->l = balanceR(h->l, z, s);
    h->r = balanceR(h->r, z, s);
    return h;
}
void BSTbalance(BST bst, int s) {
    bst->root = balanceR(bst->root, bst->z, s);
}

int BSTcamminoExceed(BST bst){
    return camminoExceed(bst->root, bst->z, 0);
}

static int max(int a, int b, int c){
    if (a>=b && a>=c)
        return a;
    if (b>=c && b>=a)
        return b;
    return c;
}

static int camminoExceed(node root , node z, int num){
    //contare il numero di archi massimo e minimo
    int a=0,b=0;
    if (root==z)
        return num-1;
    if (root->l != z || root->r!=z){
        a=camminoExceed(root->l, z, num+1);
        b=camminoExceed(root->r, z, num+1);
    }
    if (root->l==z && root->r==z)
        return num;
    return max(a,b, num);
}

int BSTcamminoMin(BST bst){
    return camminoMin(bst->root, bst->z, 0);
}

static int min(int a, int b, int c){
    if (a<=b && a<=c)
        return a;
    if (b<=c && b<=a)
        return b;
    return c;
}

static int camminoMin(node root , node z, int num){
    int a=0,b=0;
    if (root==z)
        return num-1;
    if (root->l != z || root->r!=z){
        a=camminoMin(root->l, z, num+1);
        b=camminoMin(root->r, z, num+1);
    }
    if (root->l==z && root->r==z)
        return num;
    return min(a,b, num);
}


