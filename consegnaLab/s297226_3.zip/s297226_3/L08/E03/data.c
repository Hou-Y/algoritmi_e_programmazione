#include "data.h"

void hourin(char *tdate, tempo *x){
    sscanf(tdate, " %d:%d", &(x->ora), &x->minu);
}

void datein(char *tdate, tempo *x){
    sscanf(tdate, " %d/%d/%d", &(x->anno), &(x->mm), &(x->gg));
}

int tempo_compare(tempo curr , tempo k){
    if(curr.anno == k.anno && curr.mm == k.mm && curr.gg==k.gg )
        return 0;
    if(curr.anno <= k.anno && curr.mm <= k.mm && curr.gg<=k.gg)
        return -1;
    return 1;
}
