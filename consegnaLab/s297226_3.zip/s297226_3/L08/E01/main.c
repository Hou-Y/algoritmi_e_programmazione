#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MULTIPLY 8

//SOLO RISPOSTA VALIDA
typedef enum{
    spalle, frontale
}direzione;

typedef enum{
    false, true
}bool;

typedef enum{
    transizione, indietro, avanti
}tipologia;

typedef struct diag_s{
    char *nome; //da freeare
    tipologia tipo;
    direzione ingresso;
    direzione uscita;
    bool preceduto;
    bool isfinal;
    float valore;
    int difficulty;
}element;

typedef struct diag_greedy{
    int list[5];
    float punteggio;
    int difficulty;
} diag;

void read_element(element **diag, int *N);

void greedy(diag *sol, element* ele_list, int N){
    int i, j;
    //complessità esponenziale
    for(i=0; i<N; i++){ //prima diagonale
        if(ele_list[i].tipo==avanti){
            sol[0].list[0]=i;
            for()
                sol[0].list[2]=
        }
        for(j=0; j<N; j++){
            if(ele_list[i].tipo==transizione)
                sol[1].list[0]=i;
            if(ele_list[i].tipo==indietro)
                sol[1].list[1]=i;
            if(){ //prime due righe riempite, calcolo la terza
                //rewind dal primo elemento

                //se la soluzione che trovo è accettabile e se è maggiore della soluzione salvata aggiorno
            }
        }

    }
}

int main(){
    setbuf(stdout, 0);
    element *ele_list;
    int N;
    diag sol[3];
    // un due elementi acrobatici (che per com'è posto il problema saranno due elementi frontali)
    //un elemento di transizione + un elemento con entrata di spalle
    // cerca l'ottimo
    read_element(&ele_list, &N );
    greedy(sol, ele_list, N);
    return 0;
}

void read_element(element **diag, int *N){
    FILE *in;
    int i;
    char tempname[100];
    if ((in=fopen("../elementi.txt","r"))==NULL){
        printf("Errore nell'apertura del file di lettura\n");
    }
    fscanf(in, " %d", N);
    (*diag)=(element*)malloc((*N) * sizeof(element));
    for(i=0; i<*N; i++){
        fscanf(in, " %s %d %d %d %d %d %f %d",
               tempname, //salvato
               &((*diag)[i].tipo),
               &(*diag)[i].ingresso,
               &(*diag)[i].uscita,
               &(*diag)[i].preceduto,
               &(*diag)[i].isfinal,
               &(*diag)[i].valore,
               &(*diag)[i].difficulty);
        (*diag)[i].nome=strdup(tempname);
    }
}